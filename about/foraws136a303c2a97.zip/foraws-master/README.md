# Uplift Model Package

This package was joint work with Ming Zhao at The New York Times.

**Note:** Click on `uplift/Uplift Modeling Simulation.ipynb` for a simulation if you don't feel like reading the rest. 

![](/img/uplift_sim.png?raw=true)
&nbsp;
&nbsp;
&nbsp;
  
  
**Description:**
Class for constructing uplift model for given actions `(a=0, 1, ...)` and corresponding feature set. Methods in this class are compatible with `sklearn` classifier, `GridSearch`, and `CrossValidation` classes.
    
    
It has all common methods in any sklearn classifiers with similar functionality.
    
 
 **Tips**: Parameter search for models can be done by passing the classifier `self.clf(**kargs)` to external grid search functions, and then updating attribute `self.best_model` by calling method `update_best_model()`. Or it can be carried out completely externally beforehand and then update `self.best_model`.
 
 
 **Note**: Require `sklearn v0.17` to allow support of `sample_weight` in `fit()` method. Keyword `sample_weight` **is not supported** by the `liblinear`
    solver of `LogisticRegression` (the only solver that supports $L_1$ loss).
    
 So for now, 'liblinear' is replaced by 'lbfgs' solver.

**Note on regularizer 
`lambda_`**: Because input data is weighted by their outcomes (aka rewards), those who do not respond (i.e.,`outcome==0`) will be ignored for `lambda_=0`. Thus, in the case where only a small fraction of data and a small set of features result in positive outcomes, the model will easily overfit and will not generalize as it would only take a small fraction of data into account.
    
For instance, if response highly correlates with action (i.e., outcome =1
only if action ==1), then all scenarios where action == 0 will not be seen
by the model and thus the model will not be able to predict the action==0
cases at all!

To address this problem, we have to use the hyperparameter `lambda_` and
explore it using the validation set and *un-weighted* evaluation score.
    
### Parameters
    ----------
    clf_class : sklearn model object (e.g., RF, LR, SVM, etc.), optional
                Classification object; can be fitted or not.
    lambda_ : float, optional
        Regularizer (hyperparameter) for sample weight. Need to be determined
        with griding search while optiming for whatever chosen scoring metric.
    mu_ : dict, optional, default=0.
        Pre-defined cost to reward for each action. Only need to be passed at
        class initilization or when calling `fit()`.
    kwargs : optional
        kwargs for the classification object.
    Attributes
    ------------
    best_model : sklearn model object
        Best-fit classifier.
    bias_dict: dict
        Bias term (i.e., probability) for each action. Used to calculate weight.
    clf.** : classifier attributes
        Attributes intrinsic to any inherited clf object from sklearn, such as
        clf.feature_importances_ (for RF class), clf.classes_,clf. n_classes_,
        etc.
        
        
### Examples
  Use Logistic Regression classification for uplift modeling:
    
 
 ``` from sklearn.linear_model import LogisticRegression as LR
LRUplift = UpliftModel(LR)
LRUplift.fit(Xs_train, actions_train, lambda_= 0, plot_weight_hist=True)
LR_predictions = LRUplift.predict(Xs_test)
LR_bob_curve=LRUplift.bob_curve(Xs_test, action_test, normalize_population=False, normalize_reward=False)

# Plot normalized average reward per person vs. fraction of population,
# aka, Bobby Curve:

LR_bobby_curve=LRUplift.bob_curve(Xs_test, action_test, normalize_population=True)
```


