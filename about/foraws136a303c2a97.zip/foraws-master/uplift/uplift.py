# A module for creating uplift models
from __future__ import absolute_import, division, print_function
import inspect
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn
from sklearn.linear_model import LogisticRegression as LR
from sklearn.cross_validation import StratifiedKFold
from sklearn.metrics import f1_score, roc_auc_score


class UpliftModel():
    '''Class for constructing uplift model for given actions (a=0, 1, ...) and
    corresponding feature set.

    Methods in this class are compatible with sklearn classifier,
    GridSearch, and CrossValidation classes.
    It has all common methods in any sklearn classifiers with similar
    functionality.

    **Tips**: Parameter search for models can be done by passing the classifier
    `self.clf(**kargs)` to external grid search functions, and then updating
    attribute `self.best_model` by calling method `update_best_model()`.
    Or it can be carried out completely externally beforehand and then update
    `self.best_model`.

    **Note**: Require sklearn v0.17 to allow support of sample_weight in `fit()`
    method. Keyword `sample_weight` **is not supported** by the 'liblinear'
    solver of LogisticRegression (the only solver that supports 'L1' loss).
    So for now, 'liblinear' is replaced by 'lbfgs' solver.

    **Note on regularizer `lambda_`**: Because input data is weighted by their
    outcomes (aka rewards), those who do not respond (i.e., outcome==0) will be
    ignored for lambda_=0. Thus, in the case where only a small fraction of
    data and a small set of features result in positive outcomes, the model
    will easily overfit and will not generalize as it would only take a small
    fraction of data into account.
    For instance, if response highly correlates with action (i.e., outcome =1
    only if action ==1), then all scenarios where action == 0 will not be seen
    by the model and thus the model will not be able to predict the action==0
    cases at all!

    To address this problem, we have to use the hyperparameter `lambda_` and
    explore it using the validation set and *un-weighted* evaluation score.


    Parameters
    ----------
    clf_class : sklearn model object (e.g., RF, LR, SVM, etc.), optional
                Classification object; can be fitted or not.
    lambda_ : float, optional
        Regularizer (hyperparameter) for sample weight. Need to be determined
        with griding search while optiming for whatever chosen scoring metric.
    mu_ : dict, optional, default=0.
        Pre-defined cost to reward for each action. Only need to be passed at
        class initilization or when calling `fit()`.
    kwargs : optional
        kwargs for the classification object.

    Attributes
    ------------
    best_model : sklearn model object
        Best-fit classifier.
    bias_dict: dict
        Bias term (i.e., probability) for each action. Used to calculate weight.
    clf.** : classifier attributes
        Attributes intrinsic to any inherited clf object from sklearn, such as
        clf.feature_importances_ (for RF class), clf.classes_,clf. n_classes_,
        etc.

    Examples
    ----------
    Use Logistic Regression classification for uplift modeling:

        from sklearn.linear_model import LogisticRegression as LR
        LRUplift = UpliftModel(LR)
        LRUplift.fit(Xs_train, actions_train, lambda_= 0, plot_weight_hist=True)
        LR_predictions = LRUplift.predict(Xs_test)

        LR_bob_curve=LRUplift.bob_curve(Xs_test, action_test, normalize_population=False,
                                        normalize_reward=False)

        # Plot normalized average reward per person vs. fraction of population,
        # aka, Bobby Curve:
        LR_bobby_curve=LRUplift.bob_curve(Xs_test, action_test, normalize_population=True)

    See test_fakedata_v2.py for a concrete example.
    For multi-class actions, see test_fakedata_multiclass.py
    '''

    def __init__(self,clf_class=None, lambda_=None, mu_=0, **kwargs):
        if clf_class:
            self.clf = clf_class(**kwargs)
        if lambda_:
            self.lambda_ = lambda_
        self.mu_ = mu_



    def update_model(self, clf, lambda_=None, **kwargs):
        '''Mehtod to update classification model with a fitted fuction or
        custom parameters. If the updated model is fitted, then it allows
        calling `predict()`, `bob_curve()`, or other evaluation methods without
        running `fit()` first.

        Parameters
        ----------
        clf : object for any scikit-learn model (e.g., RF, LR, SVM, etc.)
            fitted classifier or user provided model with custom parameters.
        lambda_ : float
            Regularizer term for sample weight
        **kwargs : optional
            kwargs for the classification object.

        Return
        ------
        None
        '''
        self.clf = clf(**kwargs)



    def set_params(self, lambda_=None, **kwargs):
        '''Mehtod to update model parameters. Same as `set_params()` in
        any classifier.

        This is similar to update_model, but only sets parameters, not the
        classifier.

        Parameters
        ----------
        lambda_ : float, optional
            Regularizer term for sample weight
        **kwargs : optional
            kwargs for the classification object.

        Return
        ------
        None
        '''
        self.clf = self.clf.set_params(**kwargs)
        if lambda_:
            self.lambda_ = lambda_
        return None



    def update_best_model(self, best_clf, lambda_, **kwargs):
        '''Method to update the best-fit classification model to attributes
        `best_model` AND `clf`.
        This allows calling `predict()`, `bob_curve()`, or other evaluation
        methods without running `fit()` first.

        Parameters
        ----------
        best_clf : object for any scikit-learn model (e.g., RF, LR, SVM, etc.)
            best-fit classifier
        lambda_ : float
            Regularizer term for sample weight
        kwargs : optional
            kwargs for the classification object.

        Return
        ------
        None
        '''
        self.best_model = best_clf(**kwargs)
        self.clf = self.best_model # update the clf object as well
        self.lambda_ = lambda_
        return None



    def _check_lambda_(self, lambda_):
        '''Helper method to check if lambda_ exists.
        '''
        try:
            if lambda_ is None:
                if hasattr(self, 'lambda_') and self.lambda_ != None:
                    pass
                else:
                    curframe = inspect.currentframe()
                    calframe = inspect.getouterframes(curframe)[1][3]
                    raise ValueError(calframe+' : Must provide a value for lambda_ !!!')
            else:
                self.lambda_ = lambda_
        except:
            print('Must provide a value for lambda_ !!!')


    def _check_mu_(self, mu_):
        '''Helper method to check if mu_ exists in self, since mu_ is
        pre-determined and only need to assign once.
        '''
        try:
            if mu_ is None:
                if hasattr(self, 'mu_') and self.mu_ != None:
                    pass
                else:
                    curframe = inspect.currentframe()
                    calframe = inspect.getouterframes(curframe)[1][3]
                    raise ValueError(calframe+' : Must provide a value for cost mu_ !!!')
            else:
                self.mu_ = mu_
        except:
            print('Must provide a value for mu_ !!!')


    def _check_length(self, Xs, y):
        '''Helper method to check if the length of actions or outcomes agrees
        with that of Xs.

        Parameters
        ----------
        Xs : pandas dataframe
            Full feature set for training.
        y : pandas series or numpy array
            Corresponding actions or outcomes.

        Return
        ---------
        None
        '''
        try:
            if len(y) != len(Xs):
                curframe = inspect.currentframe()
                calframe = inspect.getouterframes(curframe)[1][3]
                raise ValueError(calframe + ': dimension of actions or outcomes does not match that of Xs!!!')
        except ValueError:
            print('Dimension of y does not match that of Xs!!!')


    def _validate_nparray(self, y):
        '''Helper method to check data type of  `actions` or `outcomes`
        and convert it to numpy ndarray.

        Parameters
        ----------
        y : pandas series or numpy array
            Actions or outcomes for corresponding Xs.

        Return
        ---------
        y : numpy ndarray
            y converted to ndarray and flattened to 1D.
        '''
        try:
            if isinstance(y, (pd.Series, pd.DataFrame)):
                y = np.ravel(np.array(y)) # flattens to 1D array without copying
            elif not isinstance(y, np.ndarray):
                curframe = inspect.currentframe()
                calframe = inspect.getouterframes(curframe)[1][3]
                raise TypeError(calframe + ': `actions` or `outcomes` need to be either pd.Series, pd.DataFrame, or np.array!')
        except TypeError:
            print('Type of data = {}'.format(type(y)))
            print('Data needs to be either pd.Series, pd.DataFrame, or np.array!!!')
            raise
        return y



    def get_bias(self, actions_train):
        '''Method to calculate biases for the experiment.
        Bias is a function of actions, and is inferred from the training set
        ONLY since it is the distribution of actions from the training set!

        This function should only be called by `self.fit()` since it stays the
        same for each data set (i.e., experiment).

        Parameters
        -----------
        actions_train : pandas series or numpy array
            Actions from the training set, used for calculating biases for
            each action.

        Return
        ----------
        biases : numpy array
            Biases for each data point. Has same length as action_train.
        '''
        actions = self._validate_nparray(actions_train) # actions is now np array
        # Construct bias using dictionary as an attribute
        unique_actions, action_counts = np.unique(actions, return_counts=True)
        total_len = len(actions)
        bias={a: c/total_len for a, c in zip(unique_actions, action_counts)}
        self.bias_dict = bias
        biases = np.array([bias[a] for a in actions])
        return biases



    def get_weights(self, action, outcome, lambda_, mu_=None):
        '''Method to calculate sample weights for each data point.
        This is key for the uplift model.

           - Sample_weight = (reward - lambda_ - mu_)/Bias
           - Bias = Probability of actions = len(action_k)/len(all_data)
           - lambda_ is a regularizing hyperparameter in the weight function.

        Parameters
        -----------
        action : pandas series or numpy array
            Actions in the experiment (a=0, 1 for binary actions; a=0, 1, 2, ...
            for multiclass classification).
        outcome : numpy ndarray or pandas Series
            Outcome (aka reward) from actions, used to calculate weights.
        lambda_ : float
            Hyperparameter for reward. Acts like a regularizer for the loss
            function.
            -infinity < lambda_ < min(reward or outcome)
        mu_ : dict, optional
            Cost to reward for each action. This also acts
            like a regularizer but is pre-defined.
        clf : object, optional
            Classifier to be fitted

        Return
        ------
        weights : numpy array
            Sample weights for the loss function. Has same length as action.
        biases : numpy array
            Biases for each data point. Has same length as action. Unlike
            attribute `self.bias`, which is a dict, this is an array of biases
            for each data point.
        '''
        self._check_lambda_(lambda_)
        actions = self._validate_nparray(action) # actions is now np array
        outcomes = self._validate_nparray(outcome)

        # check the lengths of actions and outcomes
        try:
            if len(actions) != len(outcomes):
                current_frame = inspect.currentframe()
                caller_frame = inspect.getouterframes(current_frame)[1][3]
                raise ValueError(caller_frame + ': Lengths of actions and outcomes do not agree!')
        except ValueError:
            print('Lengths of actions and outcomes do not agree!. Make sure lengths of actions and outcomes agree!!!!!')

        # check mu_ to ensure it exists in self.mu_
        self._check_mu_(mu_)
        mu_ = self.mu_
        if mu_ == 0:
            muvals = np.zeros(len(actions))
        else:
            if isinstance(mu_, dict):
                if set(actions) != set(mu_.keys()):
                    current_frame = inspect.currentframe()
                    caller_frame = inspect.getouterframes(current_frame)[1][3]
                    raise ValueError(caller_frame+ ': Unique actions and mu_ dictionary keys do not match!')
                else:
                    muvals = np.array([mu_[a] for a in actions])
            else:
                current_frame = inspect.currentframe()
                caller_frame = inspect.getouterframes(current_frame)[1][3]
                raise ValueError(caller_frame + ': mu_ must be a dictionary of actions!')

        bias = self.bias_dict # load bias from dictionary for efficiency
        biases = np.array([bias[a] for a in actions])

        # Construct weight for each data point
        weights = (outcomes - self.lambda_ - muvals)/biases
        return weights, biases


    def _check_LR_solver(self):
        '''Helper to make sure the solver for LogisticRegression is NOT
        liblinear since it doesn't support sample_weight.
        '''
        if isinstance(self.clf, LR):
            if self.clf.solver == 'liblinear':
                self.clf.solver = 'lbfgs'
                self.clf.max_iter = 500
                print('''Note: LogisticRegression's liblinear solver does not support sample_weight, replaced with 'lbfgs' sovler instead! No further action needed.''')



    def fit(self, X_train, action_train, outcome_train, lambda_=None, mu_=None,
            clf=None, set_best_model=False, plot_weight_hist=False, **kwargs):
        '''Method to fit the classifier.

        Parameters
        -----------
        X_train : pandas dataframe
            Full feature set for training.
        action_train : pandas series or numpy array
            Actions to be fitted for (a=0, 1 for binary actions; a=0, 1, 2, ...
            for multiclass classification).
        outcome_train : pandas series or numpy array
            Outcomes for X_train and action_train, used for sample weights.
        lambda_ : float, optional, default = None
            Hyperparameter for reward. Acts like a regularizer.
            -infinity < lambda < min(reward)
        mu_ : dict, optional, default=0
            Pre-defined cost to reward for each action. Only need to be passed
            at class initilization or `fit()`.
        clf : object, optional
            Classifier object to be fitted
        set_best_model: boolean, optional, default=False
            Set the current fitted model as attribute `best_model`.
        plot_weight_hist : boolean, optional
            Make diagnostic plot of sample weights

        Return
        ------
        self : object
            Returns self.
        '''
        # check classifier
        try:
            if (not hasattr(self, 'clf')) and (not clf):
                raise NameError
            elif clf:
                self.clf = clf(**kwargs) # assign clf or overwrite previous version
        except NameError:
            print('fit: Must provide a classifier object to fit!')
        self._check_LR_solver()

        # check and validate data
        action_train = self._validate_nparray(action_train)
        outcome_train = self._validate_nparray(outcome_train)
        self._check_length(X_train, action_train)
        self._check_length(X_train, outcome_train)
        self._check_mu_(mu_) # check mu_ and assign to self.mu_
        self._check_lambda_(lambda_)
        print('fit: lambda_={0} , mu_={1}'.format(self.lambda_, self.mu_))

        self.get_bias(action_train) # calculate bias and store in attribute to be called later
        weights = self.get_weights(action_train, outcome_train, self.lambda_, mu_=self.mu_)[0]
        fitted = self.clf.fit(X_train, action_train, weights)
        if set_best_model:
            self.update_best_model(fitted)
        if plot_weight_hist:
            plt.figure()
            plt.hist(weights)
            plt.title('UplifModel.fit(): Sample Weights for model fitting')
        return fitted


    def predict(self, Xs):
        '''Predict actions for given Xs. Compatible with sklearn classifier
        objects.

        Parameters
        ----------
        Xs : pandas dataframe
             Full feature set for training.
             DO NOT include 'outcome' as feature.

        Return
        -------
        predicted_actions : numpy array of shape =[n_samples]
            Predicted actions.
        '''
        return self.clf.predict(Xs)



    def predict_proba(self, Xs):
        '''Probabilities for predicted actions for given Xs.
        Compatible with sklearn predict_proba objects.

        Parameters
        ----------
        Xs : pandas dataframe
             Full feature set for training.
             DO NOT include 'outcome' as feature.

        Return
        -------
        p_actions : numpy array of shape = [n_samples, n_classes],
            or a list of n_outputs.
            Class probabilities of input samples actions. The order of the
            classes corresponds to that in the attribute clf.classes_.
        '''
        return self.clf.predict_proba(Xs)



    def predict_log_proba(self, Xs):
        '''Log of probability estimates. Compatible with sklearn predict_proba
        objects. The returned estimates for all multiclasses are ordered by the
        label of classes.

        Parameters
        ----------
        Xs : pandas dataframe
             Full feature set for training.
             DO NOT include 'outcome' as feature.

        Return
        -------
        log_p_actions : numpy array of shape = [n_samples, n_classes], or a
            list of n_outputs.
             Class log probabilities of input samples actions. The order of the
             classes corresponds to that in the attribute `clf.classes_`.
        '''
        return self.clf.predict_log_proba(Xs)



    def score(self, X_test, action_test, outcome_test, weighted=False):
        '''Returns the mean accuracy on the given test data and labels.
        Same as the `score()` method in sklearn classifier objects.

        In multi-label classification, this is the subset accuracy which
        is a harsh metric since you require for each sample that each label
        set be correctly predicted.

        Parameters
        ------------
        X_test : pandas DataFrame
            Full feature set to test.
        action_test : numpy array or pandas Series
            True labels for X_test.
        outcome_test : numpy array or pandas Series
            Outcomes for corresponding actions and Xs.
        weighted : boolean, default=False
            If =True, the score is weighted as in self.fit(). However, if want
            to evaluate the score for all data points equally, then set
            weighted=False.

        Returns
        --------
        score : float
            Mean accuracy of self.predict(X) wrt. y.
        '''
        # Check data type of action_test and convert it to numpy array
        action_test = self._validate_nparray(action_test)
        outcome_test = self._validate_nparray(outcome_test)
        self._check_length(X_test, action_test)
        self._check_length(X_test, outcome_test)

        weights = self.get_weights(action_test, outcome_test, self.lambda_)[0]
        if weighted:
            return self.clf.score(X_test, action_test, weights)
        else:
            return self.clf.score(X_test, action_test)



    def apply(self, Xs):
        '''Same as the `apply()` method if exists in the classifier object
        (e.g., RandomForest).
        For details see documentation for the classifier object.
        '''
        if hasattr(self.clf, 'apply'):
            return self.clf.apply(Xs)
        else:
            return None



    def decision_function(self, Xs):
        '''Same as the `decision_function()` method if exists in the classifier
        object (e.g., LigisticRegression)

        For details see documentation for the classifier object.
        '''
        if hasattr(self.clf, 'decision_function'):
            return self.clf.decision_function(Xs)
        else:
            return None



    def _check_actual_vs_predict_action_length(self, actual_actions, predicted_actions):
        '''Helper function to check if length of actual_actions == lenght of
        predicted_actions.
        '''
        try:
            if len(actual_actions) != len(predicted_actions):
                raise ValueError
        except ValueError:
            curframe = inspect.currentframe()
            calframe = inspect.getouterframes(curframe)[1][3]
            print(calframe+' : Length of predicted_actions != length of actual_actions! \n\
            This can be addressed by simply using default: predicted_actions=None,\n\
            unless passing from outside is desired.')



    def v_score(self, Xs, actual_actions, actual_outcomes, predicted_actions=None, normalize=True):
        ''' Calculate the EXPECTATION of total weighted reward (i.e., average):
            reward_expectation = sum( Y/B * delta(a=h) ) / sum( 1/B * delta(a=h) )
        where y is outcome (aka reward) for each sample,
        B is the bias (acts like a weight) for corresponding action taken
        (i.e., probability of the action), delta(a=h) is the Kronecker delta
        function, i.e., indicator function.

        The numerator is the TOTAL, bias corrected reward, while the denominator
        is the normalizing term for a robust estimate of the AVERAGE reward.

        This is what we actually wish to maximize, which is achieved
        by minimizing the loss function.

        *Note*: this is different from `self.get_total_reward()` which is not
        weighted by bias, i.e., not importance sampled.

        Parameters
        ------------
        Xs : pandas DataFrame
            Full feature set.
        actual_actions : numpy array or pandas Series
            Actual actions taken for Xs.
        actual_outcomes : numpy array or pandas Series
            Actual outcomes for corresponding actions and feature set Xs.
        predicted_actions : numpy array, optional, default = None
            Predicted actions for Xs. If not given (default), then predict
            automatically.
        normalize : boolean, optional, default=True
            Indicate whether or not to return the robust, normalized v_score,
            i.e., with the denominator. Typically =True.

        Returns
        --------
        v_score : float
            Expectation of total reward.
            If normalize = True, then return v_score = v_top/v_bottom, i.e.,
            a robust estimate;
            otherwise return v_score = v_top/N, i.e., un-normalized average.
            *Note*: BOTH v_scores are AVERAGE reward (i.e., expectation).
        v_err : float
            Uncertainty for v_score, assuming Poisson noise and ignoring
            uncertainty for biases.
        '''
        # check actions and outcomes, and convert to np.array
        actual_actions = self._validate_nparray(actual_actions)
        actual_outcomes = self._validate_nparray(actual_outcomes)
        self._check_length(Xs, actual_actions)
        self._check_length(Xs, actual_outcomes)

        if predicted_actions is None:
            predicted_actions = self.predict(Xs)
        self._check_actual_vs_predict_action_length(actual_actions, predicted_actions)

        ind_agreed_actions = np.where(predicted_actions == actual_actions)[0]

        weights, biases = self.get_weights(actual_actions[ind_agreed_actions],
                                           actual_outcomes[ind_agreed_actions], 0) # Note here lambda_=0 !
        v_top = np.sum(weights)
        v_bottom = np.sum(1.0/biases)
        v_top_err = np.sqrt(np.sum(weights**2))
        v_bottom_err = np.sqrt(np.sum(1.0/biases**2))
        v_score_err = np.sqrt(v_top_err**2/v_bottom**2 + v_bottom_err**2 * v_top**2/v_bottom**4)
        if normalize:
            if v_bottom==0:
                return 0, 0
            else:
                return v_top / v_bottom, v_score_err
        else:
            return v_top/len(ind_agreed_actions), v_top_err/len(ind_agreed_actions) # un-normalized v_score



    def get_total_reward(self, actions, outcomes, predicted_actions, average=True):
        '''Method to calculate non-bias-weighted total reward, i.e., \n
            total_reward = sum(y * delta(a=h)) \n
        where y is outcome (aka reward) for each sample,
        delta(a=h) is the Kronecker delta function, i.e., indicator function of
        actual_actions == predicted_actions.

        *Note* : This is different from the v_score, the expectation of reward
        which is weighted, in that the total reward here is not weighted but
        only cost adjusted (i.e., mu_ value applied).

        Parameters
        ------------
        actions : numpy array or pd.Series
            Actual actions taken on data set.
        outcomes : numpy array or pd.Series
            Outcomes result from actions.
        predicted_actions : numpy array or pd.Series
            Predicted actions from the policy model.
        average : boolean, default=True
            If = True, then return AVERAGE reward = total_reward /N

        Return
        -------
        total_reward : float
            Sum of unweighted reward for where actual_actions == predicted_actions.
            If average=True (fedault), return AVERAGE reward = total_reward /N.
        total_reward_err : float
            Uncertainty of total reward.
        '''
        # check actions and outcomes, and convert to np.array
        actions = self._validate_nparray(actions)
        outcomes = self._validate_nparray(outcomes)
        predicted_actions = self._validate_nparray(predicted_actions)
        if len(actions) != len(outcomes) or len(actions) != len(predicted_actions):
            raise ValueError('Length of actions or outcomes do NOT agree with that of predicted actions!!!')

        # Construct muvals, an np.array of mu values for each action
        mu_ = self.mu_
        if mu_ == 0:
            muvals = np.zeros(len(actions))
        else:
            if isinstance(mu_, dict):
                if set(actions) != set(mu_.keys()):
                    current_frame = inspect.currentframe()
                    caller_frame = inspect.getouterframes(current_frame)[1][3]
                    raise ValueError(caller_frame+ ': Unique actions and mu_ dictionary keys do not match!')
                else:
                    muvals = np.array([mu_[a] for a in actions])
            else:
                current_frame = inspect.currentframe()
                caller_frame = inspect.getouterframes(current_frame)[1][3]
                #raise ValueError(caller_frame + ': mu_ must be a dictionary of actions!')

        ind = np.where(actions == predicted_actions)[0]
        r, r_err = np.sum((outcomes - muvals)[ind]), np.sqrt(np.sum((outcomes - muvals)[ind]))
        if average:
            r /= len(ind)
            r_err /= len(ind)
        return r, r_err



    def bob_curve(self, Xs_test, actual_actions, actual_outcomes,
                  predicted_actions=None, BAU_class=0, plot=True, plot_BAU=True,
                  compare_all_actions=True, normalize_reward=False, normalize_population=False,
                  simulate_bau_random = False, no_bias_correction = False,
                  plot_hist=False, fontsize=None, n_thresholds = 20, pdfhandle=None, **kwargs):
        '''Calculate "Bob Curve", a variant of "Lorenz curve", i.e.,
        Cumulative reward vs. cumulative faction of population to target.

        The fraction of population for the binary classification scenario is done
        by changing the threshold (predict probability) of class==1.
        In the multi-class scenario, this is done by changing the classification
        threshold (class probability) of 1- BAU. Predicted labels are kept for
        samples above the threshold, i.e., to be treated.

        Parameters
        ----------
        Xs_test : pandas DataFrame
            Full feature set. DO NOT include 'outcome' as feature.
        actual_actions : numpy array
            Actual actions for Xs_test.
        predicted_actions : numpy array, optional. Default = `None` (recommended!)
            Predicted actions for Xs_test. If not given, then call `self.predict()`
            to do it automatically. Default is recommended in general, unless
            passing the argument externally is strongly desired.
        BAU_class : int, optional. default = 0
            Business-as-Usual class label value. Typically = 0 (recommended!!!)
        normalize_reward : boolean, optional, default = False
            Normalize reward into *AVERAGE* reward per person.
        normalize_population : boolean, optional, default = False
            Normalize the number of people to treat into fraction of population.
            If = True, then `normalize_reward = True` as well!!!
            *A.K.A.* Bobby Plot.
        compare_all_actions : boolean, optional, default = True
            If = True, make 'Robert' plot, i.e., plotting reward for each
            action alone as a function of customers for comparison, either in
            fraction (normalized_population = True) or in number of customers.
        plot : boolean, optional, default=True
            Plot "Bob Curve" if True.
        plot_BAU : boolean, optional, default=False.
            For multi-class scenario, BAU_class can be plotted if =True.
        plot_hist : boolean, optional
            For diagnosis purpose only; plot the distribution of testset
            outcome if True.
        fontsize : int
            Default fontsize for figure title and labels.
        simulate_bau_random : boolean, default = False
            If True, then the BAU and random_treatment curves are simulated
            rather than calculated.
        n_thresholds : int
            Maximum number of probability thresholds to iterate through for the plot.
        pdfhandle : filehandle
            Optional matplotlib PdfPages filehandle for saving the figures to file.
        kwargs : plt.figure() keywords
            Keywords for plt.figure(), such as figsize
        no_bias_correction : boolean, default=False
            If True, then the reward is *NOT* bias corrected; otherwise it is the
            `v_score`, i.e., bias corrected or importance sampled.
            *NOTE*: typically should be False, unless you really know what you
            want!

        Returns
        --------
        result : pandas dataframe
                Results ready to make custom bob plot.\n
                Columns inclue: \n
                num_to_treat : number of customers to treat \n
                fraction_to_treat : fraction of customers to treat \n
                Rs : expected total reward (normalized) \n
                Rs_err : error bars for total reward \n
                random_Rs : expected reward for the random selection scenario
                random_err : error for random selection reward
                BAU_Rs : expected total reward for BAU scenario
                BAU_err : error for BAU reward
        '''
        if normalize_population: # normalize reward also in order to make the plot meaningful
            normalize_reward = True

        # check actions and outcomes, and convert to np.array
        actual_actions = self._validate_nparray(actual_actions)
        actual_outcomes = self._validate_nparray(actual_outcomes)
        self._check_length(Xs_test, actual_actions)
        self._check_length(Xs_test, actual_outcomes)

        if predicted_actions is None:
            predicted_actions = self.predict(Xs_test)
        self._check_actual_vs_predict_action_length(actual_actions, predicted_actions)

        # First take only those who were actually treated and agreed with predictions
        # in the test data because we will evaluate against model predictions and
        # we will test what happens when all are treated and agreed with predictions.
        # Here actual treated is defined as != BAU_class and actual_actions == predicted_actions
        ind_testset_actual_treated = np.where((actual_actions != BAU_class))[0]
        testset_actual_treated  = actual_actions[ind_testset_actual_treated] # np array
        testset_actual_outcomes = actual_outcomes[ind_testset_actual_treated] # np array
        Xs_test_actual_treated = Xs_test.iloc[ind_testset_actual_treated, :]
        predicted_actions_actual_treated = predicted_actions[ind_testset_actual_treated]

        ind_testset_BAU = np.where(actual_actions == BAU_class)[0]
        Xs_test_actual_BAU = Xs_test.iloc[ind_testset_BAU, :]
        testset_actual_BAU = actual_actions[ind_testset_BAU]
        testset_outcome_BAU = actual_outcomes[ind_testset_BAU]

        BAU_ind = np.where(self.clf.classes_ == BAU_class)[0][0]
        probabilities = self.predict_proba(Xs_test_actual_treated)
        BAU_probability = probabilities[:, BAU_ind]
        to_treat_probability = 1.0- BAU_probability # to-treat means not BAU

        # get best actions other than BAU -- this is mostly for multi-class scenatio
        cols = [c for c in range(probabilities.shape[1]) if c != BAU_ind]
        no_bau_probability = probabilities[:, cols]
        no_bau_classes = self.clf.classes_[cols]
        ind_action_other_than_bau = np.argmax(no_bau_probability, axis=1)
        action_other_than_bau = np.array([no_bau_classes[i] for i in ind_action_other_than_bau])

        # Thresholds for to_treat_probability. Add -0.001, 1.0001 to ensure both boundries are included
        thresholds = np.unique(np.sort(np.append(to_treat_probability,[-0.001,1.0001])))
        if len(thresholds) > n_thresholds:
            t = np.random.choice(thresholds, size=n_thresholds, replace=False)
            thresholds = np.unique(np.sort(np.append(t,[-0.001,1.0001])))

        if plot_hist: # plot histogram for diagnosis
            plt.figure()
            plt.hist(testset_actual_treated)
            plt.xlabel('Testset Outcome (treated, agree with predictions)')
            plt.ylabel('Counts')
            plt.title('Histogram for testset outcome (treated)')
            if pdfhandle:
                pdfhandle.savefig()

        treat_fraction = []
        n_to_treat_arr=[]
        Rs=[]
        Rs_err = []
        random_Rs = []  # for the random selection scenario
        random_Rs_err = []
        BAU_Rs=[]
        BAU_Rs_err = []
        actual_treated_length = len(testset_actual_treated)
        actual_BAU_length = len(testset_actual_BAU)
        print (thresholds)
        for t in thresholds:
            ind_to_treat = np.where(to_treat_probability >= t)[0]

            predicted_actions_per_threshold = np.zeros_like(predicted_actions_actual_treated)
            predicted_actions_per_threshold.fill(BAU_class)
            predicted_actions_per_threshold[ind_to_treat] = action_other_than_bau[ind_to_treat]

            n_to_treat = np.sum(testset_actual_treated == predicted_actions_per_threshold)
            n_to_treat_arr.append(n_to_treat)

            # r for best-fit model
            if no_bias_correction: # use non-biased-corrected reward, typically not True
                r, r_err = self.get_total_reward(testset_actual_treated, testset_actual_outcomes,
                                                 predicted_actions_per_threshold, average=True)
            else:
                r, r_err = self.v_score(Xs_test_actual_treated, testset_actual_treated,
                                        testset_actual_outcomes, predicted_actions=predicted_actions_per_threshold)
            Rs.append(r)
            Rs_err.append(r_err)

            if simulate_bau_random:
                # reward for random selection scenario
                ind_random_action = np.random.choice(actual_treated_length, size=n_to_treat, replace=False)
                random_actions = np.zeros_like(testset_actual_treated)
                random_actions.fill(BAU_class)
                random_actions[ind_random_action] = testset_actual_treated[ind_random_action]
                if no_bias_correction: # use non-biased-corrected reward, typically not True
                    random_r, random_r_err = self.get_total_reward(testset_actual_treated, testset_actual_outcomes,
                                                                   random_actions, average=True)
                else:
                    random_r, random_r_err = self.v_score(Xs_test_actual_treated, testset_actual_treated,
                                                          testset_actual_outcomes, predicted_actions=random_actions)
                random_Rs.append(random_r* n_to_treat)
                random_Rs_err.append(random_r_err * n_to_treat)

                # reward for BAU (i.e., no action for all, or treat all uniformly (& randomly) with BAU)
                    # note here actual_BAU_length is the holdout data's length and is different from
                    # that of treated data set. So need to make sure the BAU length > to_treat length
                BAU_sample_length = n_to_treat if n_to_treat < actual_BAU_length else actual_BAU_length
                ind_random_BAU_action = np.random.choice(actual_BAU_length,
                                                         size=BAU_sample_length, replace=False)
                Xs_BAU = Xs_test_actual_BAU.iloc[ind_random_BAU_action, :]
                BAU_actions = testset_actual_BAU[ind_random_BAU_action]
                BAU_outcomes = testset_outcome_BAU[ind_random_BAU_action]
                if no_bias_correction: # use non-biased-corrected reward, typically not True
                    BAU_r, BAU_r_err = self.get_total_reward(BAU_actions, BAU_outcomes, BAU_actions, average=True)
                else:
                    BAU_r, BAU_r_err = self.v_score(Xs_BAU, BAU_actions, BAU_outcomes, predicted_actions=BAU_actions)
                BAU_Rs.append(BAU_r * n_to_treat)
                BAU_Rs_err.append(BAU_r_err * n_to_treat)

        # If not simulating or to normalize_reward (i.e., use the slopes for BAU & random case)
        # then calculate the lines outside the previous loop -- this is faster!
        if (not simulate_bau_random) or normalize_reward:
            # random selection scenario.
            if no_bias_correction: # use non-biased-corrected reward, typically not True
                random_r_avg, random_r_err_avg = self.get_total_reward(testset_actual_treated, testset_actual_outcomes,
                                                                       testset_actual_treated, average=True)
            else:
                random_r_avg, random_r_err_avg = self.v_score(Xs_test_actual_treated, testset_actual_treated,
                                                              testset_actual_outcomes,
                                                              predicted_actions=testset_actual_treated)
            random_Rs = [random_r_avg * n for n in n_to_treat_arr]
            random_Rs_err = [random_r_err_avg * n for n in n_to_treat_arr]

            # BAU scenario
            if no_bias_correction: # use non-biased-corrected reward, typically not True
                BAU_r_avg, BAU_r_err_avg = self.get_total_reward(testset_actual_BAU, testset_outcome_BAU, testset_actual_BAU, average=True)
            else:
                BAU_r_avg, BAU_r_err_avg = self.v_score(Xs_test_actual_BAU, testset_actual_BAU,
                                                        testset_outcome_BAU, testset_actual_BAU)
            BAU_Rs = [BAU_r_avg * n for n in n_to_treat_arr]
            BAU_Rs_err = [BAU_r_err_avg * n for n in n_to_treat_arr]

        # Calculate rewards for all actions other than BAU individually,
        # i.e., treat with one action alone at a time for comparison
        n_unique_actions = len(set(self.bias_dict))
        if n_unique_actions ==2:
            compare_all_actions = None # Donot need this for 2-action cases
        if compare_all_actions and n_unique_actions > 2:
            a_Rs=[BAU_Rs] # rewards for all actions, including BAU so the indices are still correct
            a_Rs_err =[BAU_Rs_err]
            a_r_avg_arr = [0] # averga rewards, fill 0 as first element to ensure indices are correct
            a_r_err_avg_arr =[0]
            for a in range(1, n_unique_actions): # BAU is skipped, starting from 1
                ind_testset_action_a = np.where(actual_actions == a)[0]
                Xs_test_actual_action_a = Xs_test.iloc[ind_testset_action_a, :]
                testset_actual_action_a= actual_actions[ind_testset_action_a]
                testset_outcome_action_a = actual_outcomes[ind_testset_action_a]

                if no_bias_correction: # use non-biased-corrected reward, typically not True
                    a_r_avg, a_r_err_avg = self.get_total_reward(testset_actual_action_a,
                                                                 testset_outcome_action_a,
                                                                 testset_actual_action_a, average=True)
                else:
                    a_r_avg, a_r_err_avg = self.v_score(Xs_test_actual_action_a, testset_actual_action_a,
                                                        testset_outcome_action_a, testset_actual_action_a)
                a_r_avg_arr.append(a_r_avg)
                a_r_err_avg_arr.append(a_r_err_avg)
                a_Rs.append([a_r_avg * n for n in n_to_treat_arr])
                a_Rs_err.append([a_r_err_avg * n for n in n_to_treat_arr])
            a_Rs = np.array(a_Rs)
            a_Rs_err = np.array(a_Rs_err)

        # convert everything to np.array
        Rs = np.array(Rs)
        Rs_err = np.array(Rs_err)
        n_to_treat_arr = np.array(n_to_treat_arr)
        treat_fraction = n_to_treat_arr/np.max(n_to_treat_arr)
        random_Rs = np.array(random_Rs)
        random_Rs_err = np.array(random_Rs_err)
        BAU_Rs = np.array(BAU_Rs)
        BAU_Rs_err = np.array(BAU_Rs_err)

        if plot:
            plt.figure(**kwargs)
            max_to_treat = np.max(n_to_treat_arr)
            if normalize_population:
                x_axis = treat_fraction
                title=r'Normalized, N$_{customer}$'+'={0},  Tot_reward={1:3.2f}'.format(np.max(n_to_treat_arr), np.max(Rs * n_to_treat_arr))
                xlabel='Fraction of treated customers'
                if plot_BAU:
                    xlabel='Fraction of customers'
            else:
                x_axis = n_to_treat_arr
                title='Comparison of uplift model and other policies'
                xlabel='Number of treated customers'
                if plot_BAU:
                    xlabel='Number of customers out of N_tot={}'.format(max_to_treat)
            if normalize_reward:
                # By default rewards are normalized as average per treated person
                y1 = Rs
                y1_err = Rs_err
                y2 = np.array([random_r_avg] * len(n_to_treat_arr) )
                y2_err = np.array([random_r_err_avg] * len(n_to_treat_arr) )
                y3 = np.array([BAU_r_avg] * len(n_to_treat_arr))
                y3_err = np.array([BAU_r_err_avg] * len(n_to_treat_arr))
                ylabel='Average reward per treated customer'
            else:
                # Calculate total rewards
                y1 = Rs * n_to_treat_arr
                y1_err = Rs_err * n_to_treat_arr
                y2 = random_Rs
                y2_err = random_Rs_err
                y3 = BAU_Rs
                y3_err = BAU_Rs_err
                ylabel='Cumulative reward from treated customers'
            if len(Rs)<n_thresholds:
                marker='o'
            else:
                marker=None
            if fontsize==None:
                if n_unique_actions>3:
                    fontsize=12
                else:
                    fontsize=14


            plt.fill_between(x_axis, y2-y2_err, y2+y2_err, color='k', alpha=0.3)
            plt.plot(x_axis, y2, color='k', ls='--', alpha=0.8, label='Random treatment')
            if plot_BAU:
                plt.fill_between(x_axis, y3-y3_err, y3+y3_err, color='crimson', alpha=0.3)
                plt.plot(x_axis, y3, ls='-', color='crimson', label='BAU (action={})'.format(BAU_class))
            if compare_all_actions:
                colors = seaborn.husl_palette(n_unique_actions, l=0.55,s=1)
                for a in range(1, n_unique_actions): # starting from 1 to skip BAU
                    if normalize_reward:
                        y_action = np.array([a_r_avg_arr[a]] * len(n_to_treat_arr))
                        y_action_err = np.array([a_r_err_avg_arr[a]] * len(n_to_treat_arr))
                    else:
                        y_action = a_Rs[a, :]
                        y_action_err = a_Rs_err[a, :]
                    plt.fill_between(x_axis, y_action - y_action_err, y_action+ y_action_err,
                                     color=colors[a], alpha=0.3)
                    plt.plot(x_axis, y_action, ls='-', color=colors[a], label='Action={}'.format(a))
            # Note here I exclude error region for the 1st and last points to
            # make it clear that those 2 points are manually created and do not
            # exist in actual data! This is to avoid confusion that will happen
            # for very high accuracy classification models.
            plt.fill_between(x_axis[1:-1], (y1-y1_err)[1:-1], (y1+y1_err)[1:-1], color='royalblue', alpha=0.4)
            plt.plot(x_axis, y1, marker=marker, color='royalblue', ls='-', label='Uplift model')
            plt.xlabel(xlabel, fontsize=fontsize)
            plt.ylabel(ylabel, fontsize=fontsize)
            plt.legend(loc='best', fontsize=fontsize)
            plt.title(title, fontsize=fontsize)
            if pdfhandle:
                pdfhandle.savefig()

        result=pd.DataFrame({'threshold':thresholds, 'num_to_treat':n_to_treat_arr, 'fraction_to_treat':treat_fraction,
                             'model_reward':Rs * n_to_treat_arr, 'model_err':Rs_err * n_to_treat_arr,
                             'random_reward':random_Rs, 'random_err':random_Rs_err,
                             'BAU_reward':BAU_Rs, 'BAU_err':BAU_Rs_err})
        if compare_all_actions:
            for a in range(1, n_unique_actions):
                result['action_{}_reward'.format(a)] = a_Rs[a, :]
                result['action_{}_err'.format(a)] = a_Rs_err[a, :]
        return result



    def plot_importances(self, X_train, action_train, outcome_train,
            n_folds=3, pdfhandle=None, **kwargs):

        '''Plot the feature importances for the classifier.

        Uses either feature_importances_ or coef_.
        User beware: with Logistic Regression, if your features are not normalized than
        these coefficients will not represent importances.

        Parameters
        ----------
        X_train : pandas DataFrame
            Full feature set. DO NOT include 'outcome' as feature.
        action_train : numpy array
            Actual actions for X_train.
        outcome_train : pandas series or numpy array
            Outcomes for X_train and action_train, used for sample weights.
        n_folds : int, default = 3
            Number of cross-validation folds for calculating uncertainty in importances
        pdfhandle : filehandle
            Optional matplotlib PdfPages filehandle for saving the figures to file.
        kwargs : keywords
            Keywords for plt.figure(), such as figsize

        Returns
        --------
        None
        '''
        # Calculate the feature weights
        # fit with cross-validation to get uncertainty
        n_classes = len(np.unique(action_train))
        feature_names = X_train.columns
        f_weights = np.zeros((n_folds, n_classes, X_train.shape[1]))
        skf = StratifiedKFold(action_train, n_folds)
        for t, (train, test) in enumerate(skf):
            self.fit(X_train.iloc[train], action_train[train], outcome_train[train],
            set_best_model=False, plot_weight_hist=False, **kwargs)
            try:
                importances = self.clf.coef_ # LR
            except AttributeError:
                importances = self.clf.feature_importances_ # RF

            importances = np.atleast_2d(importances)
            f_weights[t,:,:] = importances

        # make a plot for each class
        # if there are only two classes, only make one plot.
        if n_classes == 2:
            n_classes = 1
        for c in range(n_classes):

            class_weights = f_weights[:,c,:]
            medians = np.median(class_weights, axis=0)
            indices = np.argsort(abs(medians))[::-1]
            positive = medians > 0

            class_weights[:,~positive] *= -1
            # sort by weight median
            class_weights = class_weights[:,indices]

            fnames = feature_names[indices]

            color = np.array(['Negative']*len(fnames))
            color[positive] = 'Positive'
            color = color[indices]

            fig = plt.figure()
            title = ''
            if n_classes > 1:
                title = 'Class {0} '.format(c)
            title += 'Feature importances'
            ax0 = fig.add_subplot(111, title=title)

            fw_array = []
            fn_array = []
            fc_array = []
            for i in range(class_weights.shape[1]):
                if fnames[indices[i]] == 'Constant':
                    continue
                for j in range(class_weights.shape[0]):
                    fn_array.append(fnames[i])
                    fc_array.append(color[i])
                    fw_array.append(class_weights[j,i])
            df_boxplot = pd.DataFrame({'fweights':fw_array, 'fnames':fn_array, 'color':fc_array})
            palette = seaborn.xkcd_palette(['green','red'])
            seaborn.boxplot(x='fweights', y='fnames', hue='color', data=df_boxplot, order=fn_array[::3][:15], orient='h', palette=palette, ax=ax0)
            plt.gcf().subplots_adjust(left=0.3)

            if pdfhandle:
                pdfhandle.savefig()

        return


    def plot_learning_curve(self, X_train, action_train, outcome_train, 
            n_folds=3, train_fractions=[0.1,0.3,0.5,0.7,0.9], pdfhandle=None, **kwargs):

        '''Plot the learning curve for the classifier.

        Plots the classification score for training and test sets as you increase the 
        number of data points in those sets.  Shows bias and variance of your fit.  
        Uses the F1 score, to be valid with unbalanced data.

        Parameters
        ----------
        X_train : pandas DataFrame
            Full feature set. DO NOT include 'outcome' as feature.
        action_train : numpy array
            Actual actions for X_train.
        outcome_train : pandas series or numpy array
            Outcomes for X_train and action_train, used for sample weights.
        n_folds : int, default = 3
            Number of cross-validation folds for calculating uncertainty in importances
        train_fractions : array, default = [0.1,0.3,0.5,0.7,0.9]
            The fraction of the data set used for each data point in the plot.  Each 
            data point uses cross-validation with n_folds folds.  So, if train_fraction=0.5 
            and n_folds=3 then during cross-validation, 0.5 of the data is split into 3 subsets.
        pdfhandle : filehandle
            Optional matplotlib PdfPages filehandle for saving the figures to file.
        kwargs : keywords
            Keywords for plt.figure(), such as figsize

        Returns
        --------
        None
        '''

        weights = self.get_weights(action_train, outcome_train, self.lambda_)[0]

        train_sizes = np.array(len(action_train)*np.array(train_fractions) + 0.5, dtype=int)

        n_classes = len(np.unique(self.clf.classes_))
        score_average_type = 'binary'
        if n_classes > 2:
            score_average_type = 'weighted'

        # Loop over different sized subsets of the training set
        train_results = np.zeros((len(train_sizes), n_folds))
        test_results = np.zeros((len(train_sizes), n_folds))
        for i, train_size in enumerate(train_sizes):
            indices = np.random.choice(2, size=len(action_train)).astype(bool)
            X_subset = X_train[indices]
            weights_subset = weights[indices]
            action_subset = action_train[indices]
            outcome_subset = outcome_train[indices]

            # we're evaluating the inner classification, not anything involving the reward
            skf = StratifiedKFold(action_subset, n_folds)

            for t, (train, test) in enumerate(skf):
                self.fit(X_subset.iloc[train], action_subset[train], outcome_subset[train], 
                set_best_model=False, plot_weight_hist=False, **kwargs)
                action_pred = self.predict(X_subset)
                train_results[i,t] = f1_score(action_subset[train], action_pred[train], sample_weight=weights_subset[train], average=score_average_type)
                test_results[i,t] = f1_score(action_subset[test], action_pred[test], sample_weight=weights_subset[test], average=score_average_type)

        train_scores_mean = np.mean(train_results, axis=1)
        train_scores_std = np.std(train_results, axis=1)
        test_scores_mean = np.mean(test_results, axis=1)
        test_scores_std = np.std(test_results, axis=1)

        fig = plt.figure()
        ax0 = fig.add_subplot(111, ylim=(0.0,1.0))
        ax0.grid()
        ax0.set_xlabel("Training examples")
        ax0.set_ylabel("Score")
        ax0.fill_between(train_sizes, train_scores_mean - train_scores_std,
                         train_scores_mean + train_scores_std, alpha=0.1,
                         color="r")
        ax0.fill_between(train_sizes, test_scores_mean - test_scores_std,
                         test_scores_mean + test_scores_std, alpha=0.1, color="g")
        ax0.plot(train_sizes, train_scores_mean, 'o-', color="r",
                 label="Training score")
        ax0.plot(train_sizes, test_scores_mean, 'o-', color="g",
                 label="Cross-validation score")
        ax0.grid()
        plt.legend(loc="best")
        # plt.close(fig)

        if pdfhandle:
            pdfhandle.savefig()

        return None

